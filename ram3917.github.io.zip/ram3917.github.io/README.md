# ram3917.github.io

Personal brand site for Rama Mallavarapu — Software Engineer, ADAS & Autonomous Systems.

Live at: **https://ram3917.github.io**

## What's in here

```
index.html                                   → the whole site (single self-contained file)
resumes/Rama_Mallavarapu_Resume_EN.pdf        → English resume, ATS-friendly
resumes/Rama_Mallavarapu_Lebenslauf_DE.pdf    → German resume, ATS-friendly
.github/workflows/deploy.yml                  → GitHub Actions workflow that deploys to Pages
```

No build step, no dependencies — it's plain HTML/CSS/JS. GitHub Actions just packages the repo and publishes it to Pages on every push to `main`.

## One-time setup (do this once)

1. Create a **public** repository on GitHub named exactly **`ram3917.github.io`** (this exact name makes it your GitHub Pages "user site," served at the root domain instead of a `/repo-name/` subpath).
2. Push this folder's contents to the `main` branch of that repository (see commands below).
3. In the repo, go to **Settings → Pages**, and under "Build and deployment" set **Source** to **"GitHub Actions"** (not "Deploy from a branch"). This only needs to be done once — after that, the workflow in `.github/workflows/deploy.yml` handles every deployment automatically.
4. Push to `main` (or go to the **Actions** tab and manually run the "Deploy to GitHub Pages" workflow). The site will be live at `https://ram3917.github.io` within a minute or two.

## Pushing this folder to GitHub

From inside this folder:

```bash
git init
git add .
git commit -m "Initial site"
git branch -M main
git remote add origin https://github.com/ram3917/ram3917.github.io.git
git push -u origin main
```

## Updating the site later

Edit `index.html` (or swap the PDFs in `resumes/`), then:

```bash
git add .
git commit -m "Update site"
git push
```

The Actions workflow redeploys automatically — no manual build or upload needed.

## Updating your resumes

Replace the two PDFs in `resumes/` with new exports, **keeping the same filenames** (`Rama_Mallavarapu_Resume_EN.pdf` and `Rama_Mallavarapu_Lebenslauf_DE.pdf`) so the download buttons on the site keep working without any HTML changes.

## Adding your photo later

You mentioned you'd add a headshot later. When ready:
1. Add the image file to an `assets/` folder (e.g. `assets/headshot.jpg`).
2. In `index.html`, inside the `<header class="hero">` section, add an `<img>` tag pointing to it, or let me know and I can wire it into the hero layout directly.
